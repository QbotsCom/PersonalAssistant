package com.turlygazhy.entity;

/**
 * Created by user on 12/26/16.
 */
public enum MessageElement {
    PHOTO,
    TEXT
}
