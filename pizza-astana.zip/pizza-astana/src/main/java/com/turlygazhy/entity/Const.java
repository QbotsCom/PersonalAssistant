package com.turlygazhy.entity;

/**
 * Created by user on 2/23/17.
 */
public class Const {
    public static final String ACCESS_TO_BOT = "access to bot";
    public static final String TO_GROUP = "to group";

}
