package com.turlygazhy.entity;

/**
 * Created by user on 2/24/17.
 */
public class UserResult {
    private int completed;
    private int goalId;
    private int id;

    public int getCompleted() {
        return completed;
    }

    public void setCompleted(int completed) {
        this.completed = completed;
    }

    public void setGoalId(int goalId) {
        this.goalId = goalId;
    }

    public int getGoalId() {
        return goalId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
