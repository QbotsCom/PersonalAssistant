package com.turlygazhy.exception;

/**
 * Created by user on 1/2/17.
 */
public class NotRealizedMethodException extends RuntimeException {

    public NotRealizedMethodException(String message) {
        super(message);
    }
}
