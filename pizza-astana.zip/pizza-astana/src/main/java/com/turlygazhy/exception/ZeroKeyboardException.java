package com.turlygazhy.exception;

/**
 * Threw it when need keep previous keyboard
 * Created by user on 1/3/17.
 */
public class ZeroKeyboardException extends Throwable {
}
